<?php

require_once implode(DIRECTORY_SEPARATOR, array(dirname(__FILE__), '..', 'vendor')) . '/autoload.php';

class TestCase extends PHPUnit_Framework_TestCase
{

	public function setUp()
	{
	}

}
