<?php
namespace PhpSigep\Model;

/**
 * @author: Stavarengo
 */
class DestinoInternacional extends AbstractModel implements Destino
{

}