<?php
namespace PhpSigep\Model;

/**
 * @author: Stavarengo
 */
interface Destino
{

}