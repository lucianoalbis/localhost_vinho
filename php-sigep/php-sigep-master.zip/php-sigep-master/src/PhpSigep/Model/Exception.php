<?php
namespace PhpSigep\Model;

/**
 * @author: Stavarengo
 */
class Exception extends \Exception
{

}