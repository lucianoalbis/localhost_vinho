<?php
namespace PhpSigep\Model;
use PhpSigep\DefaultStdClass;

/**
 * @author: Stavarengo
 */
abstract class AbstractModel extends DefaultStdClass
{
}