<?php

namespace PhpSigep\Cache\Storage\Adapter\Exception;

class InvalidAdapterException extends \PhpSigep\Exception
{
}
