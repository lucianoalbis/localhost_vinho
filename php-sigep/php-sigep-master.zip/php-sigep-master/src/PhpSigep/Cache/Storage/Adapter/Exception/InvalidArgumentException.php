<?php

namespace PhpSigep\Cache\Storage\Adapter\Exception;

class InvalidArgumentException extends \PhpSigep\Exception
{
}
