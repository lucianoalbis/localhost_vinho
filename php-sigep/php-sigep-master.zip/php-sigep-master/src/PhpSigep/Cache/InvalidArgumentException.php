<?php

namespace PhpSigep\Cache;

class InvalidArgumentException extends \PhpSigep\Exception
{
}
