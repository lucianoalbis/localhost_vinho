<?php


namespace PhpSigep\Services\Real\Exception\RastrearObjeto;


/**
 * @author: Stavarengo
 */
class TipoResultadoInvalidoException extends \PhpSigep\Exception
{

}