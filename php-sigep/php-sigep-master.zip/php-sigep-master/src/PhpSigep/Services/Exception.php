<?php
namespace PhpSigep\Services;

/**
 * @author: Stavarengo
 */
class Exception extends \Exception
{

}