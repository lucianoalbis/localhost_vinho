<?php


namespace PhpSigep\Pdf;


/**
 * @author: Stavarengo
 */
class InvalidArgument extends \PhpSigep\Exception
{

}