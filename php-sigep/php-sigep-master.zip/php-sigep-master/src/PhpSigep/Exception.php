<?php
namespace PhpSigep;

/**
 * @author: Stavarengo
 */
class Exception extends \Exception
{

} 