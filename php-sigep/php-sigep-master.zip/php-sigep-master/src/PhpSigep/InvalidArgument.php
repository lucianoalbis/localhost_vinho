<?php


namespace PhpSigep;


/**
 * @author: Stavarengo
 */
class InvalidArgument extends \PhpSigep\Exception
{

}